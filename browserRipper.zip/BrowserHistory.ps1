<#
.SYNOPSIS
    BrowserHistory.ps1 - Forensic browser history extractor
    Chrome / Edge / Brave | PowerShell 5 | No external dependencies
.NOTES
    Extracts: URLs, titles, visit counts, last visit time
              Downloads (path, URL, state, timestamps)
              Search terms (omnibox queries)
    All timestamps converted from Chrome epoch to UTC ISO 8601
    History database is unencrypted - works on live and offline images
.USAGE
    .\BrowserHistory.ps1
    .\BrowserHistory.ps1 -ExportPath C:\cases\history.csv
    .\BrowserHistory.ps1 -ExportPath C:\cases\history.csv -Since "2024-01-01"
    .\BrowserHistory.ps1 -Tables URLs,Downloads,Searches
    .\BrowserHistory.ps1 -UserProfile "C:\Users\tony.stark" -ExportPath C:\cases\out.csv
#>

#Requires -Version 5

param(
    [string]$ExportPath   = "",
    [string]$Since        = "",
    [string]$UserProfile  = $env:USERPROFILE,
    [ValidateSet("URLs","Downloads","Searches","All")]
    [string]$Tables       = "All",
    [switch]$Help
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "SilentlyContinue"

if ($Help) {
    Write-Host "Usage: .\BrowserHistory.ps1 [-ExportPath <path>] [-Since YYYY-MM-DD] [-Tables URLs|Downloads|Searches|All] [-UserProfile <path>]"
    exit
}

# ---------------------------------------------
# INLINE C# - SQLITE PARSER + TIME CONVERSION
# Reuses same B-tree logic as BrowserRip
# Adds multi-table support and Chrome epoch conversion
# ---------------------------------------------
$inlineCS = @"
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

public class HistoryReader {

    // Chrome/WebKit epoch: microseconds since 1601-01-01
    // Unix epoch offset: 11644473600 seconds
    public static DateTime ChromeTimeToUtc(long chromeTime) {
        try {
            long unixMicro = chromeTime - 11644473600L * 1000000L;
            long unixMs    = unixMicro / 1000;
            return DateTimeOffset.FromUnixTimeMilliseconds(unixMs).UtcDateTime;
        } catch {
            return DateTime.MinValue;
        }
    }

    public static string FormatTime(long chromeTime) {
        if (chromeTime <= 0) return "";
        var dt = ChromeTimeToUtc(chromeTime);
        return dt == DateTime.MinValue ? "" : dt.ToString("yyyy-MM-dd HH:mm:ss");
    }

    public class UrlRow {
        public long   Id;
        public string Url;
        public string Title;
        public long   VisitCount;
        public long   TypedCount;
        public long   LastVisitTime;
        public string LastVisitStr;
    }

    public class DownloadRow {
        public string TargetPath;
        public string Url;
        public string ReferrerUrl;
        public long   StartTime;
        public string StartTimeStr;
        public long   EndTime;
        public string EndTimeStr;
        public long   ReceivedBytes;
        public long   TotalBytes;
        public string State;
        public string MimeType;
    }

    public class SearchRow {
        public string Term;
        public string Url;
    }

    // -- SQLite binary parser ---------------------------------

    static int PageSize(byte[] db) {
        int ps = (db[16] << 8) | db[17];
        return (ps == 1) ? 65536 : ps;
    }

    static int U16(byte[] db, int off) {
        return (db[off] << 8) | db[off + 1];
    }

    static int U32(byte[] db, int off) {
        return (db[off] << 24) | (db[off+1] << 16) | (db[off+2] << 8) | db[off+3];
    }

    static long Varint(byte[] d, ref int o) {
        long r = 0;
        for (int i = 0; i < 9; i++) {
            byte b = d[o++];
            if (i < 8) { r = (r << 7) | (b & 0x7FL); if ((b & 0x80) == 0) break; }
            else        { r = (r << 8) | b; }
        }
        return r;
    }

    static int SerialLen(long t) {
        if (t <= 0)  return 0;
        if (t == 1)  return 1;
        if (t == 2)  return 2;
        if (t == 3)  return 3;
        if (t == 4)  return 4;
        if (t == 5)  return 6;
        if (t == 6)  return 8;
        if (t == 7)  return 8;
        if (t == 8 || t == 9) return 0;
        if (t >= 12 && t % 2 == 0) return (int)((t - 12) / 2);
        if (t >= 13 && t % 2 == 1) return (int)((t - 13) / 2);
        return 0;
    }

    static object SerialVal(byte[] d, int o, long t) {
        if (t == 0) return null;
        if (t == 1) return (long)(sbyte)d[o];
        if (t == 2) return (long)(short)((d[o] << 8) | d[o+1]);
        if (t == 3) return (long)((d[o] << 16) | (d[o+1] << 8) | d[o+2]);
        if (t == 4) return (long)((d[o] << 24) | (d[o+1] << 16) | (d[o+2] << 8) | d[o+3]);
        if (t == 5) { long v=0; for(int i=0;i<6;i++) v=(v<<8)|d[o+i]; return v; }
        if (t == 6) { long v=0; for(int i=0;i<8;i++) v=(v<<8)|d[o+i]; return v; }
        if (t == 8) return 0L;
        if (t == 9) return 1L;
        if (t >= 12 && t % 2 == 0) {
            int len = (int)((t-12)/2);
            byte[] b = new byte[len];
            if (len > 0) Array.Copy(d, o, b, 0, len);
            return b;
        }
        if (t >= 13 && t % 2 == 1) {
            int len = (int)((t-13)/2);
            return (len > 0) ? Encoding.UTF8.GetString(d, o, len) : "";
        }
        return null;
    }

    static object[] ParseRecord(byte[] db, int payloadStart) {
        int pos = payloadStart;
        long headerBytes = Varint(db, ref pos);
        int  headerEnd   = payloadStart + (int)headerBytes;
        var  types       = new List<long>();
        while (pos < headerEnd) types.Add(Varint(db, ref pos));
        var vals = new object[types.Count];
        int vp = headerEnd;
        for (int c = 0; c < types.Count; c++) {
            vals[c] = SerialVal(db, vp, types[c]);
            vp += SerialLen(types[c]);
        }
        return vals;
    }

    static string S(object[] cols, int idx) {
        if (idx >= cols.Length) return "";
        return cols[idx] as string ?? "";
    }

    static long L(object[] cols, int idx) {
        if (idx >= cols.Length) return 0;
        return cols[idx] is long ? (long)cols[idx] : 0;
    }

    // Find root page of named table
    static int FindRoot(byte[] db, int ps, string table) {
        return ScanMaster(db, ps, 1, table);
    }

    static int ScanMaster(byte[] db, int ps, int pageNum, string table) {
        int pageOff  = (pageNum - 1) * ps;
        if (pageOff + ps > db.Length) return 0;
        int  hdrOff  = (pageNum == 1) ? 100 : 0;
        byte pageType = db[pageOff + hdrOff];
        int  cellCount = U16(db, pageOff + hdrOff + 3);
        int  ptrOff  = pageOff + hdrOff + ((pageType == 0x05) ? 12 : 8);

        if (pageType == 0x05) {
            for (int i = 0; i < cellCount; i++) {
                int cellOff   = U16(db, ptrOff + i * 2);
                int childPage = U32(db, pageOff + cellOff);
                int found = ScanMaster(db, ps, childPage, table);
                if (found > 0) return found;
            }
            int rightPage = U32(db, pageOff + hdrOff + 8);
            return ScanMaster(db, ps, rightPage, table);
        }

        if (pageType == 0x0D) {
            for (int i = 0; i < cellCount; i++) {
                int cellOff = U16(db, ptrOff + i * 2);
                int absCell = pageOff + cellOff;
                int pos = absCell;
                try {
                    Varint(db, ref pos);
                    Varint(db, ref pos);
                    var cols = ParseRecord(db, pos);
                    if (cols.Length > 3) {
                        string name = cols[1] as string;
                        if (name == table && cols[3] is long) return (int)(long)cols[3];
                    }
                } catch {}
            }
        }
        return 0;
    }

    // Walk B-tree and collect raw rows
    static void WalkRows(byte[] db, int ps, int pageNum, List<object[]> rows) {
        int pageOff = (pageNum - 1) * ps;
        if (pageOff + ps > db.Length) return;
        byte pageType  = db[pageOff];
        int  cellCount = U16(db, pageOff + 3);
        int  ptrOff    = pageOff + ((pageType == 0x05) ? 12 : 8);

        if (pageType == 0x05) {
            for (int i = 0; i < cellCount; i++) {
                int cellOff   = U16(db, ptrOff + i * 2);
                int childPage = U32(db, pageOff + cellOff);
                WalkRows(db, ps, childPage, rows);
            }
            int rightPage = U32(db, pageOff + 8);
            WalkRows(db, ps, rightPage, rows);
            return;
        }
        if (pageType != 0x0D) return;

        for (int i = 0; i < cellCount; i++) {
            int cellOff = U16(db, ptrOff + i * 2);
            int absCell = pageOff + cellOff;
            int pos = absCell;
            try {
                Varint(db, ref pos);
                Varint(db, ref pos);
                rows.Add(ParseRecord(db, pos));
            } catch {}
        }
    }

    static List<object[]> ReadTable(byte[] db, string tableName) {
        var rows = new List<object[]>();
        int ps   = PageSize(db);
        int root = FindRoot(db, ps, tableName);
        if (root < 1) return rows;
        WalkRows(db, ps, root, rows);
        return rows;
    }

    // -- Public extraction methods ----------------------------

    public static List<UrlRow> ReadUrls(string path, long sinceChrome) {
        var result = new List<UrlRow>();
        byte[] db = File.ReadAllBytes(path);
        if (db.Length < 100) return result;

        // urls table: id(0) url(1) title(2) visit_count(3) typed_count(4) last_visit_time(5) hidden(6)
        foreach (var cols in ReadTable(db, "urls")) {
            try {
                long lastVisit = L(cols, 5);
                if (sinceChrome > 0 && lastVisit < sinceChrome) continue;
                result.Add(new UrlRow {
                    Id            = L(cols, 0),
                    Url           = S(cols, 1),
                    Title         = S(cols, 2),
                    VisitCount    = L(cols, 3),
                    TypedCount    = L(cols, 4),
                    LastVisitTime = lastVisit,
                    LastVisitStr  = FormatTime(lastVisit)
                });
            } catch {}
        }

        result.Sort((a, b) => b.LastVisitTime.CompareTo(a.LastVisitTime));
        return result;
    }

    public static List<DownloadRow> ReadDownloads(string path) {
        var result = new List<DownloadRow>();
        byte[] db = File.ReadAllBytes(path);
        if (db.Length < 100) return result;

        // downloads: id(0) guid(1) current_path(2) target_path(3) start_time(4)
        //            received_bytes(5) total_bytes(6) state(7) danger_type(8)
        //            interrupt_reason(9) hash(10) end_time(11) ... referrer(15)
        //            site_url(16) tab_url(17) ... mime_type(24)
        string[] states = new[] { "In Progress", "Complete", "Cancelled", "Interrupted", "Unknown" };

        foreach (var cols in ReadTable(db, "downloads")) {
            try {
                long stateVal = L(cols, 7);
                string stateStr = (stateVal >= 0 && stateVal < states.Length - 1)
                    ? states[stateVal] : "Unknown";

                result.Add(new DownloadRow {
                    TargetPath    = S(cols, 3),
                    Url           = S(cols, 17),  // tab_url often has original URL
                    ReferrerUrl   = S(cols, 15),
                    StartTime     = L(cols, 4),
                    StartTimeStr  = FormatTime(L(cols, 4)),
                    EndTime       = L(cols, 11),
                    EndTimeStr    = FormatTime(L(cols, 11)),
                    ReceivedBytes = L(cols, 5),
                    TotalBytes    = L(cols, 6),
                    State         = stateStr,
                    MimeType      = S(cols, 24)
                });
            } catch {}
        }

        result.Sort((a, b) => b.StartTime.CompareTo(a.StartTime));
        return result;
    }

    public static List<SearchRow> ReadSearches(string path, byte[] urlDb) {
        var result  = new List<SearchRow>();
        byte[] db   = File.ReadAllBytes(path);
        if (db.Length < 100) return result;

        // Build url_id -> url lookup from urls table
        var urlMap = new System.Collections.Generic.Dictionary<long, string>();
        if (urlDb != null) {
            foreach (var cols in ReadTable(urlDb, "urls")) {
                try {
                    long id = L(cols, 0);
                    string url = S(cols, 1);
                    if (!urlMap.ContainsKey(id)) urlMap[id] = url;
                } catch {}
            }
        }

        // keyword_search_terms: keyword_id(0) url_id(1) lower_term(2) term(3)
        foreach (var cols in ReadTable(db, "keyword_search_terms")) {
            try {
                long urlId  = L(cols, 1);
                string term = S(cols, 3);
                if (string.IsNullOrEmpty(term)) term = S(cols, 2);
                string url  = urlMap.ContainsKey(urlId) ? urlMap[urlId] : "";
                if (!string.IsNullOrEmpty(term)) {
                    result.Add(new SearchRow { Term = term, Url = url });
                }
            } catch {}
        }
        return result;
    }
}
"@

if (-not ([System.Management.Automation.PSTypeName]'HistoryReader').Type) {
    try {
        Add-Type -TypeDefinition $inlineCS -Language CSharp
        Write-Host "[+] Runtime types compiled OK" -ForegroundColor DarkGray
    } catch {
        Write-Host "[-] Compile failed: $_" -ForegroundColor Red
        exit 1
    }
} else {
    Write-Host "[+] Runtime types loaded" -ForegroundColor DarkGray
}

# ---------------------------------------------
# HELPERS
# ---------------------------------------------

# Convert Since date string to Chrome epoch
function Get-ChromeEpoch {
    param([string]$DateStr)
    if ($DateStr -eq "") { return 0L }
    try {
        $dt      = [DateTime]::Parse($DateStr, $null, [System.Globalization.DateTimeStyles]::AssumeUniversal)
        $unixMs  = [DateTimeOffset]::new($dt).ToUnixTimeMilliseconds()
        $chromeMicro = ($unixMs * 1000L) + (11644473600L * 1000000L)
        return $chromeMicro
    } catch {
        Write-Warning "Could not parse date '$DateStr' - ignoring filter"
        return 0L
    }
}

function Copy-ToTemp {
    param([string]$Path)
    $tmp = Join-Path $env:TEMP ("BH_" + [IO.Path]::GetRandomFileName() + ".db")
    try {
        Copy-Item $Path $tmp -Force -ErrorAction Stop
        return $tmp
    } catch {
        return $null
    }
}

function Find-BrowserProfiles {
    param([string]$BaseDir)
    $browsers = @(
        [PSCustomObject]@{ Name="Microsoft Edge"; UD=Join-Path $BaseDir "AppData\Local\Microsoft\Edge\User Data" },
        [PSCustomObject]@{ Name="Google Chrome";  UD=Join-Path $BaseDir "AppData\Local\Google\Chrome\User Data" },
        [PSCustomObject]@{ Name="Brave";          UD=Join-Path $BaseDir "AppData\Local\BraveSoftware\Brave-Browser\User Data" }
    )
    $found = @()
    foreach ($b in $browsers) {
        if (-not (Test-Path $b.UD)) { continue }
        $dirs = Get-ChildItem $b.UD -Directory |
                Where-Object { $_.Name -eq "Default" -or $_.Name -match "^Profile \d+$" }
        foreach ($d in $dirs) {
            $hist = Join-Path $d.FullName "History"
            if (Test-Path $hist) {
                $found += [PSCustomObject]@{
                    Browser = $b.Name
                    Profile = $d.Name
                    History = $hist
                }
            }
        }
    }
    return $found
}

# ---------------------------------------------
# MAIN
# ---------------------------------------------

Write-Host ""
Write-Host "==============================================" -ForegroundColor Cyan
Write-Host "  BrowserHistory.ps1 - DFIR History Extractor" -ForegroundColor Cyan
Write-Host "  Chrome / Edge / Brave | PowerShell 5      " -ForegroundColor Cyan
Write-Host "==============================================" -ForegroundColor Cyan
Write-Host ""

$sinceChrome = Get-ChromeEpoch -DateStr $Since
if ($Since -ne "") {
    Write-Host "[*] Filtering results since: $Since" -ForegroundColor DarkGray
}

$profiles = Find-BrowserProfiles -BaseDir $UserProfile

if ($profiles.Count -eq 0) {
    Write-Host "[-] No browser history found under: $UserProfile" -ForegroundColor Red
    exit 0
}

$allUrls      = @()
$allDownloads = @()
$allSearches  = @()

foreach ($p in $profiles) {
    Write-Host ("[*] {0} | {1}" -f $p.Browser, $p.Profile) -ForegroundColor Yellow

    $tmp = Copy-ToTemp -Path $p.History
    if (-not $tmp) {
        Write-Warning "    Could not copy History DB - skipping"
        continue
    }

    try {
        if ($Tables -eq "All" -or $Tables -eq "URLs") {
            $urls = [HistoryReader]::ReadUrls($tmp, $sinceChrome)
            Write-Host ("    URLs:      {0}" -f $urls.Count) -ForegroundColor DarkGray
            foreach ($u in $urls) {
                $allUrls += [PSCustomObject]@{
                    Browser   = $p.Browser
                    Profile   = $p.Profile
                    LastVisit = $u.LastVisitStr
                    Visits    = $u.VisitCount
                    Typed     = $u.TypedCount
                    Title     = $u.Title
                    URL       = $u.Url
                }
            }
        }

        if ($Tables -eq "All" -or $Tables -eq "Downloads") {
            $downloads = [HistoryReader]::ReadDownloads($tmp)
            Write-Host ("    Downloads: {0}" -f $downloads.Count) -ForegroundColor DarkGray
            foreach ($dl in $downloads) {
                $allDownloads += [PSCustomObject]@{
                    Browser       = $p.Browser
                    Profile       = $p.Profile
                    StartTime     = $dl.StartTimeStr
                    EndTime       = $dl.EndTimeStr
                    State         = $dl.State
                    TargetPath    = $dl.TargetPath
                    SourceURL     = $dl.Url
                    ReferrerURL   = $dl.ReferrerUrl
                    ReceivedBytes = $dl.ReceivedBytes
                    TotalBytes    = $dl.TotalBytes
                    MimeType      = $dl.MimeType
                }
            }
        }

        if ($Tables -eq "All" -or $Tables -eq "Searches") {
            # Pass raw db bytes for url lookup
            $dbBytes = [IO.File]::ReadAllBytes($tmp)
            $searches = [HistoryReader]::ReadSearches($tmp, $dbBytes)
            Write-Host ("    Searches:  {0}" -f $searches.Count) -ForegroundColor DarkGray
            foreach ($s in $searches) {
                $allSearches += [PSCustomObject]@{
                    Browser = $p.Browser
                    Profile = $p.Profile
                    Term    = $s.Term
                    URL     = $s.Url
                }
            }
        }

    } catch {
        Write-Warning "    Read failed: $_"
    } finally {
        Remove-Item $tmp -Force -ErrorAction SilentlyContinue
    }
}

# ---------------------------------------------
# DISPLAY SUMMARY
# ---------------------------------------------
Write-Host ""

if ($allUrls.Count -gt 0) {
    Write-Host "--- URL History ({0} entries) ---" -f $allUrls.Count -ForegroundColor Cyan
    $allUrls | Select-Object -First 20 |
        Format-Table LastVisit, Visits, Browser, @{L="Title";E={$_.Title.Substring(0,[Math]::Min(40,$_.Title.Length))}}, @{L="URL";E={$_.URL.Substring(0,[Math]::Min(80,$_.URL.Length))}} -AutoSize
    if ($allUrls.Count -gt 20) {
        Write-Host ("    ... and {0} more. Use -ExportPath to get full output." -f ($allUrls.Count - 20)) -ForegroundColor DarkGray
    }
}

if ($allDownloads.Count -gt 0) {
    Write-Host ""
    Write-Host ("--- Downloads ({0} entries) ---" -f $allDownloads.Count) -ForegroundColor Cyan
    $allDownloads | Select-Object -First 10 |
        Format-Table StartTime, State, Browser, @{L="File";E={Split-Path $_.TargetPath -Leaf}}, @{L="Source";E={$_.SourceURL.Substring(0,[Math]::Min(60,$_.SourceURL.Length))}} -AutoSize
    if ($allDownloads.Count -gt 10) {
        Write-Host ("    ... and {0} more. Use -ExportPath to get full output." -f ($allDownloads.Count - 10)) -ForegroundColor DarkGray
    }
}

if ($allSearches.Count -gt 0) {
    Write-Host ""
    Write-Host ("--- Search Terms ({0} entries) ---" -f $allSearches.Count) -ForegroundColor Cyan
    $allSearches | Select-Object -First 20 |
        Format-Table Browser, Profile, Term -AutoSize
    if ($allSearches.Count -gt 20) {
        Write-Host ("    ... and {0} more. Use -ExportPath to get full output." -f ($allSearches.Count - 20)) -ForegroundColor DarkGray
    }
}

# ---------------------------------------------
# EXPORT
# ---------------------------------------------
if ($ExportPath -ne "") {
    try {
        $dir = Split-Path $ExportPath -Parent
        if ($dir -and -not (Test-Path $dir)) { New-Item $dir -ItemType Directory -Force | Out-Null }

        $base = [IO.Path]::GetFileNameWithoutExtension($ExportPath)
        $ext  = [IO.Path]::GetExtension($ExportPath)
        $dirP = Split-Path $ExportPath -Parent

        if ($allUrls.Count -gt 0) {
            $urlFile = Join-Path $dirP ($base + "_urls" + $ext)
            $allUrls | Export-Csv -Path $urlFile -NoTypeInformation -Encoding UTF8
            Write-Host ("[+] URLs exported:      {0} -> {1}" -f $allUrls.Count, $urlFile) -ForegroundColor Green
        }

        if ($allDownloads.Count -gt 0) {
            $dlFile = Join-Path $dirP ($base + "_downloads" + $ext)
            $allDownloads | Export-Csv -Path $dlFile -NoTypeInformation -Encoding UTF8
            Write-Host ("[+] Downloads exported: {0} -> {1}" -f $allDownloads.Count, $dlFile) -ForegroundColor Green
        }

        if ($allSearches.Count -gt 0) {
            $srFile = Join-Path $dirP ($base + "_searches" + $ext)
            $allSearches | Export-Csv -Path $srFile -NoTypeInformation -Encoding UTF8
            Write-Host ("[+] Searches exported:  {0} -> {1}" -f $allSearches.Count, $srFile) -ForegroundColor Green
        }

    } catch {
        Write-Warning "Export failed: $_"
    }
}

Write-Host ""
Write-Host "==============================================" -ForegroundColor Cyan
Write-Host ("  Done. URLs:{0} Downloads:{1} Searches:{2}" -f $allUrls.Count, $allDownloads.Count, $allSearches.Count) -ForegroundColor Cyan
Write-Host "==============================================" -ForegroundColor Cyan
