<#
.SYNOPSIS
    SQLiteDiag.ps1 - Raw SQLite column inspector for Chrome Login Data
    Pure PowerShell - no C#, no compilation, no caching issues
    Run this to see exactly what column values are in the logins table
#>

param([string]$DbPath = "")

if ($DbPath -eq "") {
    $candidates = @(
        (Join-Path $env:USERPROFILE "AppData\Local\Google\Chrome\User Data\Default\Login Data"),
        (Join-Path $env:USERPROFILE "AppData\Local\Microsoft\Edge\User Data\Default\Login Data")
    )
    foreach ($c in $candidates) {
        if (Test-Path $c) { $DbPath = $c; break }
    }
}

if (-not (Test-Path $DbPath)) {
    Write-Host "[-] No Login Data found. Use -DbPath" -ForegroundColor Red
    exit 1
}

Write-Host "[*] Reading: $DbPath" -ForegroundColor Cyan
$tmp = Join-Path $env:TEMP ("diag_" + [IO.Path]::GetRandomFileName() + ".db")
Copy-Item $DbPath $tmp -Force
$db = [IO.File]::ReadAllBytes($tmp)
Remove-Item $tmp -Force -ErrorAction SilentlyContinue

Write-Host "[*] File size: $($db.Length) bytes" -ForegroundColor Cyan

# Page size
$ps = ([int][int]$db[16] -shl 8) -bor [int]$db[17]
if ($ps -eq 1) { $ps = 65536 }
Write-Host "[*] Page size: $ps" -ForegroundColor Cyan

# Varint reader
function Read-Varint {
    param([byte[]]$d, [ref]$pos)
    $r = 0L
    for ($i = 0; $i -lt 9; $i++) {
        $b = $d[$pos.Value++]
        if ($i -lt 8) {
            $r = ($r -shl 7) -bor ($b -band 0x7F)
            if (($b -band 0x80) -eq 0) { break }
        } else {
            $r = ($r -shl 8) -bor $b
        }
    }
    return $r
}

# Serial type length
function Get-SerialLen {
    param([long]$t)
    if ($t -le 0)  { return 0 }
    if ($t -eq 1)  { return 1 }
    if ($t -eq 2)  { return 2 }
    if ($t -eq 3)  { return 3 }
    if ($t -eq 4)  { return 4 }
    if ($t -eq 5)  { return 6 }
    if ($t -eq 6)  { return 8 }
    if ($t -eq 7)  { return 8 }
    if ($t -eq 8 -or $t -eq 9) { return 0 }
    if ($t -ge 12 -and ($t % 2) -eq 0) { return [int](($t - 12) / 2) }
    if ($t -ge 13 -and ($t % 2) -eq 1) { return [int](($t - 13) / 2) }
    return 0
}

# Serial type description
function Get-SerialDesc {
    param([long]$t)
    if ($t -eq 0)  { return "NULL" }
    if ($t -eq 1)  { return "INT8" }
    if ($t -eq 2)  { return "INT16" }
    if ($t -eq 3)  { return "INT24" }
    if ($t -eq 4)  { return "INT32" }
    if ($t -eq 5)  { return "INT48" }
    if ($t -eq 6)  { return "INT64" }
    if ($t -eq 7)  { return "FLOAT" }
    if ($t -eq 8)  { return "INT=0" }
    if ($t -eq 9)  { return "INT=1" }
    if ($t -ge 12 -and ($t % 2) -eq 0) { return "BLOB($([int](($t-12)/2)))" }
    if ($t -ge 13 -and ($t % 2) -eq 1) { return "TEXT($([int](($t-13)/2)))" }
    return "UNKNOWN($t)"
}

# Find logins root page via sqlite_master (page 1)
# Page 1 header starts at offset 100
$pt    = $db[100]
$cc    = ([int][int]$db[103] -shl 8) -bor [int]$db[104]
$cpOff = 108  # cell pointer array

Write-Host ""
Write-Host "--- sqlite_master (page 1) ---" -ForegroundColor Yellow
Write-Host "  page type: 0x$($pt.ToString('X2'))"
Write-Host "  cell count: $cc"

$loginsRoot = 0

# Collect all leaf pages to scan (handles interior + leaf page 1)
$leafPages = @()
function Get-LeafPages {
    param([int]$PageNum)
    $pOff = ($PageNum - 1) * $ps
    $pType = $db[$pOff + $(if ($PageNum -eq 1) { 100 } else { 0 })]
    $hOff  = if ($PageNum -eq 1) { 100 } else { 0 }
    $pCC   = ([int][int]$db[$pOff + $hOff + 3] -shl 8) -bor [int]$db[$pOff + $hOff + 4]
    $pCP   = $pOff + $hOff + $(if ($pType -eq 0x05) { 12 } else { 8 })

    if ($pType -eq 0x05) {
        # Interior: right-most pointer at hOff+8
        $rightPage = ([int][int]$db[$pOff+$hOff+8] -shl 24) -bor ([int][int]$db[$pOff+$hOff+9] -shl 16) -bor ([int][int]$db[$pOff+$hOff+10] -shl 8) -bor [int]$db[$pOff+$hOff+11]
        for ($ci = 0; $ci -lt $pCC; $ci++) {
            $cPtr  = ([int][int]$db[$pCP+$ci*2] -shl 8) -bor [int]$db[$pCP+$ci*2+1]
            $absC  = $pOff + $cPtr
            $child = ([int][int]$db[$absC] -shl 24) -bor ([int][int]$db[$absC+1] -shl 16) -bor ([int][int]$db[$absC+2] -shl 8) -bor [int]$db[$absC+3]
            Get-LeafPages $child
        }
        Get-LeafPages $rightPage
    } elseif ($pType -eq 0x0D) {
        $script:leafPages += $PageNum
    }
}
Get-LeafPages 1

Write-Host "  Leaf pages found: $($leafPages -join ', ')"

foreach ($leafPage in $leafPages) {
    $lOff = ($leafPage - 1) * $ps
    $lHO  = if ($leafPage -eq 1) { 100 } else { 0 }
    $lCC  = ([int][int]$db[$lOff+$lHO+3] -shl 8) -bor [int]$db[$lOff+$lHO+4]
    $lCP  = $lOff + $lHO + 8

    for ($i = 0; $i -lt $lCC; $i++) {
        $cptr   = ([int][int]$db[$lCP + $i*2] -shl 8) -bor [int]$db[$lCP + $i*2 + 1]
        $pos    = $lOff + $cptr
        $posRef = [ref]$pos

        Read-Varint $db $posRef | Out-Null  # payload size
        Read-Varint $db $posRef | Out-Null  # rowid

        $recStart = $pos
        $hb       = Read-Varint $db $posRef
        $hend     = $recStart + [int]$hb

        $types = @()
        while ($pos -lt $hend) { $types += Read-Varint $db $posRef }

        $vp = $hend
        $rowName = ""; $rootPage = 0
        for ($c2 = 0; $c2 -lt $types.Count; $c2++) {
            $t  = $types[$c2]
            $sl = Get-SerialLen $t
            if ($c2 -eq 1 -and $t -ge 13 -and ($t % 2) -eq 1) {
                $rowName = [Text.Encoding]::UTF8.GetString($db, $vp, $sl)
            }
            if ($c2 -eq 3) {
                if ($t -ge 1 -and $t -le 6) {
                    $sl2 = Get-SerialLen $t
                    $rootPage = 0
                    for ($bi = 0; $bi -lt $sl2; $bi++) { $rootPage = ($rootPage -shl 8) -bor [int]$db[$vp + $bi] }
                } elseif ($t -eq 8) { $rootPage = 0 } elseif ($t -eq 9) { $rootPage = 1 }
            }
            $vp += $sl
        }
        Write-Host ("  row: name='{0}' rootpage={1}" -f $rowName, $rootPage)
        if ($rowName -eq "logins") { $loginsRoot = $rootPage }
    }
}

Write-Host ""
Write-Host "[*] logins root page: $loginsRoot" -ForegroundColor Cyan

if ($loginsRoot -lt 1) {
    Write-Host "[-] Could not find logins table" -ForegroundColor Red
    exit 1
}

# Read logins leaf page
$pageOff = ($loginsRoot - 1) * $ps
$lpt     = $db[$pageOff]
$lcc     = ([int][int]$db[$pageOff + 3] -shl 8) -bor [int]$db[$pageOff + 4]
$lcpOff  = $pageOff + 8

Write-Host "--- logins table (page $loginsRoot) ---" -ForegroundColor Yellow
Write-Host "  page type: 0x$($lpt.ToString('X2'))"
Write-Host "  cell count: $lcc"
Write-Host ""

for ($i = 0; $i -lt $lcc; $i++) {
    $cptr  = ([int][int]$db[$lcpOff + $i*2] -shl 8) -bor [int]$db[$lcpOff + $i*2 + 1]
    $pos   = $pageOff + $cptr
    $posRef = [ref]$pos

    Read-Varint $db $posRef | Out-Null  # payload size
    Read-Varint $db $posRef | Out-Null  # rowid

    $recStart = $pos
    $hb       = Read-Varint $db $posRef
    $hend     = $recStart + [int]$hb

    Write-Host ("  Row {0}: header_bytes={1} header_end=0x{2:X4}" -f $i, $hb, $hend)

    $types = @()
    while ($pos -lt $hend) {
        $types += Read-Varint $db $posRef
    }

    Write-Host ("  Serial types ({0}): {1}" -f $types.Count, ($types -join ", "))

    # Walk values
    $vp = $hend
    for ($c2 = 0; $c2 -lt $types.Count; $c2++) {
        $t   = $types[$c2]
        $sl  = Get-SerialLen $t
        $desc = Get-SerialDesc $t

        if ($t -ge 13 -and ($t % 2) -eq 1) {
            $str = [Text.Encoding]::UTF8.GetString($db, $vp, $sl)
            Write-Host ("    col[{0}] {1} vp={2} len={3}: '{4}'" -f $c2, $desc, $vp, $sl, $str) -ForegroundColor Green
        } elseif ($t -ge 12 -and ($t % 2) -eq 0) {
            Write-Host ("    col[{0}] {1} vp={2} len={3}: <blob>" -f $c2, $desc, $vp, $sl) -ForegroundColor DarkYellow
        } else {
            $ival = 0L
            for ($bi = 0; $bi -lt $sl; $bi++) { $ival = ($ival -shl 8) -bor $db[$vp + $bi] }
            Write-Host ("    col[{0}] {1} vp={2} len={3}: {4}" -f $c2, $desc, $vp, $sl, $ival) -ForegroundColor Gray
        }
        $vp += $sl
    }
    Write-Host ""
}
